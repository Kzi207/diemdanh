/**
 * UNICHECK BACKEND - VERSION 2.2
 * Chức năng: Quản lý Lớp, Sinh viên, Môn học, Hoạt động, Điểm danh, User
 */

const APP_VERSION = "2.2"; // Định danh phiên bản để Frontend kiểm tra

// Tên các Sheet Database
const DB_CLASSES = "_DB_Classes_";
const DB_STUDENTS = "_DB_Students_";
const DB_SUBJECTS = "_DB_Subjects_"; 
const DB_ACTIVITIES = "_DB_Activities_"; 
const DB_ATTENDANCE = "_DB_Attendance_";
const DB_USERS = "_DB_Users_";

// Hàm xử lý chính khi Web App gọi vào
function doPost(e) {
  const lock = LockService.getScriptLock();
  // Đợi tối đa 30 giây để tránh xung đột dữ liệu
  if (lock.tryLock(30000)) {
    try {
      // 1. Kiểm tra dữ liệu gửi lên
      if (!e || !e.postData || !e.postData.contents) {
         return responseJSON({ error: "No post data received" });
      }

      const params = JSON.parse(e.postData.contents);
      const ss = SpreadsheetApp.getActiveSpreadsheet();
      
      // 2. Khởi tạo Database nếu chưa có
      setupDatabase(ss); 

      let result = {};
      const action = params.action;

      // 3. Phân loại hành động
      switch (action) {
        // --- SYSTEM CHECK ---
        case 'GET_SYSTEM_STATUS':
          result = { 
            status: 'ok', 
            version: APP_VERSION,
            timestamp: new Date(),
            sheetName: ss.getName()
          };
          break;

        // --- READ (Lấy dữ liệu) ---
        case 'GET_CLASSES':
          result = readSheet(ss, DB_CLASSES);
          break;
        case 'GET_STUDENTS':
          result = getStudents(ss, params.classId);
          break;
        case 'GET_SUBJECTS':
          result = readSheet(ss, DB_SUBJECTS);
          break;
        case 'GET_ACTIVITIES':
          result = readSheet(ss, DB_ACTIVITIES);
          break;
        case 'GET_ATTENDANCE':
          result = getAttendance(ss, params.activityId);
          break;
        case 'GET_USERS':
          result = readSheet(ss, DB_USERS);
          break;

        // --- WRITE (Ghi dữ liệu) ---
        case 'CREATE_CLASS':
          // id, name, created_at
          appendRow(ss, DB_CLASSES, [params.id, params.name, new Date()]);
          result = { success: true };
          break;
          
        case 'UPDATE_CLASS':
          updateClass(ss, params.id, params.name);
          result = { success: true };
          break;
          
        case 'DELETE_CLASS':
          deleteClass(ss, params.id);
          result = { success: true };
          break;
          
        case 'IMPORT_STUDENTS':
          insertStudents(ss, params.students);
          result = { success: true, count: params.students.length };
          break;
          
        case 'CREATE_SUBJECT':
          ensureSheetExists(ss, DB_SUBJECTS); // Đảm bảo bảng tồn tại
          const sub = params.subject;
          // id, name, classId
          appendRow(ss, DB_SUBJECTS, [sub.id, sub.name, sub.classId]);
          result = { success: true };
          break;
          
        case 'CREATE_ACTIVITY':
          ensureSheetExists(ss, DB_ACTIVITIES); // Đảm bảo bảng tồn tại
          const act = params.activity;
          // id, name, classId, dateTime, subjectId
          appendRow(ss, DB_ACTIVITIES, [act.id, act.name, act.classId, act.dateTime, act.subjectId || '']);
          result = { success: true };
          break;
          
        case 'ADD_ATTENDANCE_RECORD':
          ensureSheetExists(ss, DB_ATTENDANCE); // Đảm bảo bảng tồn tại
          const rec = params.record;
          // id, activityId, studentId, timestamp
          appendRow(ss, DB_ATTENDANCE, [rec.id, rec.activityId, "'" + rec.studentId, rec.timestamp]);
          result = { success: true };
          break;
          
        case 'CREATE_USER':
          const u = params.user;
          // username, password, name, role
          appendRow(ss, DB_USERS, [u.username, u.password, u.name, u.role]);
          result = { success: true };
          break;
          
        case 'DELETE_USER':
          deleteUser(ss, params.username);
          result = { success: true };
          break;

        default:
          result = { error: 'Unknown action: ' + action };
      }

      return responseJSON(result);

    } catch (e) {
      return responseJSON({ error: "Server Error: " + e.toString() });
    } finally {
      lock.releaseLock();
    }
  } else {
    return responseJSON({ error: "Server Busy (Timeout)" });
  }
}

function responseJSON(data) {
  return ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

// --- CORE DB FUNCTIONS ---

function ensureSheetExists(ss, sheetName) {
  if (!ss.getSheetByName(sheetName)) {
     setupDatabase(ss);
  }
}

function setupDatabase(ss) {
  const schemas = [
    { name: DB_CLASSES, headers: ['id', 'name', 'created_at'] },
    { name: DB_STUDENTS, headers: ['id', 'lastName', 'firstName', 'dob', 'classId'] },
    { name: DB_SUBJECTS, headers: ['id', 'name', 'classId'] },
    { name: DB_ACTIVITIES, headers: ['id', 'name', 'classId', 'dateTime', 'subjectId'] },
    { name: DB_ATTENDANCE, headers: ['id', 'activityId', 'studentId', 'timestamp'] },
    { name: DB_USERS, headers: ['username', 'password', 'name', 'role'] }
  ];

  schemas.forEach(schema => {
    let sheet = ss.getSheetByName(schema.name);
    if (!sheet) {
      sheet = ss.insertSheet(schema.name);
      sheet.appendRow(schema.headers);
    } else {
       // Migration: Kiểm tra và thêm cột subjectId cho bảng Activities nếu thiếu
       if(schema.name === DB_ACTIVITIES) {
         const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
         if (!headers.includes('subjectId')) {
            sheet.getRange(1, headers.length + 1).setValue('subjectId');
         }
       }
    }
  });
}

function readSheet(ss, sheetName) {
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet || sheet.getLastRow() < 2) return [];
  
  const data = sheet.getDataRange().getValues();
  const results = [];
  
  // Dòng 0 là header, bắt đầu đọc từ dòng 1
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    let obj = {};
    
    // Mapping dữ liệu dựa trên thứ tự cột
    if (sheetName === DB_CLASSES) {
       obj = { id: String(row[0]), name: row[1] };
    } else if (sheetName === DB_SUBJECTS) {
       obj = { id: String(row[0]), name: row[1], classId: String(row[2]) };
    } else if (sheetName === DB_ACTIVITIES) {
       obj = { 
         id: String(row[0]), 
         name: row[1], 
         classId: String(row[2]), 
         dateTime: row[3],
         subjectId: row[4] ? String(row[4]) : '' 
       };
    } else if (sheetName === DB_USERS) {
       obj = { username: String(row[0]), password: row[1], name: row[2], role: row[3] };
    }
    results.push(obj);
  }
  return results;
}

function getStudents(ss, classId) {
  const sheet = ss.getSheetByName(DB_STUDENTS);
  if (!sheet || sheet.getLastRow() < 2) return [];

  const data = sheet.getDataRange().getValues();
  const results = [];
  for (let i = 1; i < data.length; i++) {
    const rowClassId = data[i][4];
    // Lọc theo classId nếu có yêu cầu
    if (!classId || String(rowClassId) === String(classId)) {
      results.push({
        id: String(data[i][0]),
        lastName: data[i][1],
        firstName: data[i][2],
        dob: data[i][3],
        classId: String(rowClassId)
      });
    }
  }
  return results;
}

function getAttendance(ss, activityId) {
  const sheet = ss.getSheetByName(DB_ATTENDANCE);
  if (!sheet || sheet.getLastRow() < 2) return [];

  const data = sheet.getDataRange().getValues();
  const results = [];
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][1]) === String(activityId)) {
      results.push({
        id: data[i][0],
        activityId: String(data[i][1]),
        studentId: String(data[i][2]),
        timestamp: data[i][3]
      });
    }
  }
  return results;
}

function appendRow(ss, sheetName, rowData) {
  const sheet = ss.getSheetByName(sheetName);
  sheet.appendRow(rowData);
}

function insertStudents(ss, students) {
  const sheet = ss.getSheetByName(DB_STUDENTS);
  
  // Lấy danh sách ID đã tồn tại để tránh trùng lặp
  let existingIds = new Set();
  if (sheet.getLastRow() > 1) {
    const data = sheet.getRange(2, 1, sheet.getLastRow() - 1, 1).getValues();
    data.forEach(r => existingIds.add(String(r[0])));
  }

  const rowsToAdd = [];
  students.forEach(s => {
    if (!existingIds.has(String(s.id))) {
      rowsToAdd.push([
        "'" + s.id, // Thêm dấu ' để Excel không tự format số
        s.lastName,
        s.firstName,
        s.dob,
        s.classId
      ]);
      existingIds.add(String(s.id));
    }
  });

  if (rowsToAdd.length > 0) {
    sheet.getRange(sheet.getLastRow() + 1, 1, rowsToAdd.length, 5).setValues(rowsToAdd);
  }
}

function deleteUser(ss, username) {
  const sheet = ss.getSheetByName(DB_USERS);
  const data = sheet.getDataRange().getValues();
  const newData = [data[0]]; // Giữ lại header
  let found = false;
  
  for(let i=1; i<data.length; i++) {
    if (String(data[i][0]) !== String(username)) {
      newData.push(data[i]);
    } else { 
      found = true; 
    }
  }
  
  if (found) {
    sheet.clearContents();
    if(newData.length > 0) {
       sheet.getRange(1, 1, newData.length, newData[0].length).setValues(newData);
    }
  }
}

function updateClass(ss, id, newName) {
  const sheet = ss.getSheetByName(DB_CLASSES);
  const data = sheet.getDataRange().getValues();
  for(let i=1; i<data.length; i++) {
    if (String(data[i][0]) === String(id)) {
      sheet.getRange(i+1, 2).setValue(newName);
      break;
    }
  }
}

function deleteClass(ss, id) {
  const sheet = ss.getSheetByName(DB_CLASSES);
  const data = sheet.getDataRange().getValues();
  for(let i=1; i<data.length; i++) {
    if (String(data[i][0]) === String(id)) {
      sheet.deleteRow(i+1);
      break;
    }
  }
}